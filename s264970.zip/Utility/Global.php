<?php
define("ROWS", 10);
define("COLUMNS", 6);
?>
